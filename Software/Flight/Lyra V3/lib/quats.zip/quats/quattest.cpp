#include "quats.h"
#include "stdio.h"

Quaternion q(1,1,1,1);

Quaternion q1(0,1,0,0)  ;

Quaternion xaxis(0,1,0,0);
Quaternion yaxis(0,0,1,0);
Quaternion zaxis(0,0,0,1);

Quaternion multaxis(0,1,1,0);


Quaternion qinv = inv(q);
Quaternion qcon = q.conjugate();

Quaternion qaa = axisangletoquat(20,multaxis,false);

Quaternion q1rot = rotate(q1,multaxis,45);

const Vector3float gyromes = {20,20,0};

//Quaternion q2gyro = intergrategyros(q1,gyromes,1);

Quaternion qtorot(1,0,0,0);


void printquat(Quaternion qtoprint){
    printf("%f,%fi,%fj,%fk\n",qtoprint.r.w,qtoprint.r.x,qtoprint.r.y,qtoprint.r.z);
}


int main(){

    printquat(qaa);

    qtorot.r = intergrategyros(qtorot,gyromes,1);


    printquat(qtorot);


    //qtorot.r = intergrategyros(qtorot,gyromes,1);

    //printquat(qtorot);

    Vector3float euler;

    //printf("cos 90 = %f")

    euler = Quattoeuler(qtorot.r);

    printf("%f,%f,%f\n",euler.x,euler.y,euler.z);


    //printquat(q2gyro);
}
